# Struktur Folder
---
Example-dataset/
│
├── labelData.csv
├── Contoh Input Data/
│ ├── a0001.wav
│ ├── a0002.wav
│ ├── a0003.wav
│ ├── ...
├── README.md

Folder ini merupakan contoh sample beberapa dataset yang dapat menjadi input pada hasil harya Penelitian ini. Apabila ingin melihat dataset secara lengkap dapat diakses melalui link berikut [PhysioNet Challenge 2016](https://archive.physionet.org/pn3/challenge/2016/).